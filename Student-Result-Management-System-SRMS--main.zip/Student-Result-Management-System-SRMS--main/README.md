# 🎓 Student Result Management System (SRMS)

A web-based **Student Result Management System** built using **Flask (Python)**, **MySQL**, and **HTML/CSS/JavaScript**.  
The system allows an **admin** to manage student results, while **students** can securely view their results.

---

## 🚀 Features
- Admin login authentication
- Add and manage student marks
- View student results
- Generate result PDF
- Backend REST APIs using Flask
- MySQL database integration
- Secure configuration using environment variables (`.env`)

---

## 🛠️ Tech Stack
- **Backend:** Python, Flask
- **Frontend:** HTML, CSS, JavaScript
- **Database:** MySQL
- **Version Control:** Git & GitHub

---

## 🗂️ Entity Relationship (ER) Diagram

The following ER diagram represents the database design of the **Student Result Management System (SRMS)**.

- **USER**, **STUDENT**, and **SUBJECT** are **strong entities**.
- **MARKS** is a **weak associative entity**.
- The **MARKS** entity resolves the **many-to-many relationship** between **STUDENT** and **SUBJECT** using a **composite primary key** `(roll_no, subject_id)`.

![ER Diagram](screenshots/er_diagram.png)

---

## 📂 Project Structure

- SRMS/
- ├── app.py
- ├── frontend/
- │ ├── login.html
- │ ├── admin.html
- │ ├── admin_dashboard.html
- │ ├── result.html
- │ └── css/
- │ └── style.css
- ├── screenshots/
- │ ├── er_diagram.png
- │ ├── admin_login.png
- │ ├── admin_dashboard1.png
- │ ├── admin_dashboard2.png
- │ ├── student_login.png
- │ ├── result.png
- │ └── result_pdf.png
- ├── .gitignore
- ├── .env.example
- ├── requirements.txt
- ├── README.md
- ├── LICENSE
-  ⚠️ `.env` and `venv/` are intentionally not pushed to GitHub for security reasons.

---

## 📸 Screenshots

### 🔐 Admin Login
![Admin Login](screenshots/admin_login.png)

### 🧑‍💼 Admin Dashboard
![Admin Dashboard](screenshots/admin_dashboard1.png)
![Admin Dashboard](screenshots/admin_dashboard2.png)

### 👨‍🎓 Student Login
![Student Login](screenshots/student_login.png)

### 📄 Student Result Page
![Result Page](screenshots/result.png)

### 🧾 Result PDF Generation
![Result PDF](screenshots/result_pdf.png)

---

## ⚙️ Setup Instructions (Local)

---

## 1️⃣ Clone the repository
- git clone https://github.com/vishal2313/Student-Result-Management-System-SRMS-.git
- cd Student-Result-Management-System-SRMS-

---

## 2️⃣ Create virtual environment
- python3 -m venv venv
- source venv/bin/activate

---

## 3️⃣ Install dependencies
- pip install -r requirements.txt

---

## 4️⃣ Create .env file
- Create a .env file in the root directory:
- DB_USER=your_db_user
- DB_PASSWORD=your_db_password
- DB_HOST=127.0.0.1
- DB_NAME=srms
- DB_PORT=3306
- ⚠️ .env is ignored by Git for security reasons.

---

## 5️⃣ Run the application
- python app.py
- Open browser:
- http://127.0.0.1:5000

---

## 🔐 Security
- Sensitive data (DB credentials) are stored in .env
- .env is excluded using .gitignore
- This ensures the project is safe for public repositories

---

## 📌 Future Improvements
- Password hashing
- Role-based authentication
- Student login module
- Cloud deployment (Render / AWS / Heroku)

---

## 👤 Author
- Vishal Sonkar
