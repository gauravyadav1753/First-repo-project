from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import mysql.connector
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
import io
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app)

# ---------- DB CONFIG ----------
DB_CONFIG = {
    "user": os.getenv("DB_USER"),
    "password": os.getenv("DB_PASSWORD"),
    "host": os.getenv("DB_HOST"),
    "database": os.getenv("DB_NAME"),
    "port": int(os.getenv("DB_PORT", 3306))
}

def get_db():
    return mysql.connector.connect(**DB_CONFIG)

# ---------- GRADE CALCULATION ----------
def calculate_grade(marks):
    if marks >= 90:
        return "A+"
    elif marks >= 80:
        return "A"
    elif marks >= 70:
        return "B"
    elif marks >= 60:
        return "C"
    elif marks >= 50:
        return "D"
    elif marks >= 40:
        return "E"
    else:
        return "Fail"

# ---------- HOME ----------
@app.route("/")
def home():
    return "SRMS Backend Running"

# ---------- LOGIN ----------
@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    email = data.get("email")
    password = data.get("password")

    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE email=%s", (email,))
    user = cursor.fetchone()
    cursor.close()
    db.close()

    if not user or user["password"] != password:
        return jsonify({"error": "Invalid email or password"}), 401

    return jsonify({
        "message": "Login successful",
        "email": user["email"],
        "role": user.get("role", "admin")
    })

# ================= STUDENTS =================

# ADD STUDENT
@app.route("/students", methods=["POST"])
def add_student():
    data = request.get_json()
    db = get_db()
    cursor = db.cursor()
    cursor.execute(
        "INSERT INTO students (roll_no, name, semester, academic_year) VALUES (%s,%s,%s,%s)",
        (data["roll_no"], data["name"], data["semester"], data["academic_year"])
    )
    db.commit()
    cursor.close()
    db.close()
    return jsonify({"message": "Student added successfully"})

# EDIT STUDENT
@app.route("/students", methods=["PUT"])
def edit_student():
    data = request.get_json()
    db = get_db()
    cursor = db.cursor()

    cursor.execute("""
        UPDATE students
        SET name=%s, semester=%s, academic_year=%s
        WHERE roll_no=%s
    """, (
        data["name"],
        data["semester"],
        data["academic_year"],
        data["roll_no"]
    ))

    db.commit()
    cursor.close()
    db.close()
    return jsonify({"message": "Student updated successfully"})

# ================= SUBJECTS =================

# ADD SUBJECT
@app.route("/subjects", methods=["POST"])
def add_subject():
    data = request.get_json()
    db = get_db()
    cursor = db.cursor()
    cursor.execute(
        "INSERT INTO subjects (subject_name) VALUES (%s)",
        (data["subject_name"],)
    )
    db.commit()
    cursor.close()
    db.close()
    return jsonify({"message": "Subject added successfully"})

# EDIT SUBJECT
@app.route("/subjects", methods=["PUT"])
def edit_subject():
    data = request.get_json()
    db = get_db()
    cursor = db.cursor()

    cursor.execute("""
        UPDATE subjects
        SET subject_name=%s
        WHERE id=%s
    """, (
        data["subject_name"],
        data["id"]
    ))

    db.commit()
    cursor.close()
    db.close()
    return jsonify({"message": "Subject updated successfully"})

# GET SUBJECTS
@app.route("/subjects", methods=["GET"])
def get_subjects():
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM subjects")
    rows = cursor.fetchall()
    cursor.close()
    db.close()
    return jsonify({"subjects": rows})

# ================= MARKS =================

# ADD MARKS
@app.route("/marks", methods=["POST"])
def add_marks():
    data = request.get_json()
    db = get_db()
    cursor = db.cursor()
    cursor.execute(
        "INSERT INTO marks (roll_no, subject_id, marks) VALUES (%s,%s,%s)",
        (data["roll_no"], data["subject_id"], data["marks"])
    )
    db.commit()
    cursor.close()
    db.close()
    return jsonify({"message": "Marks added successfully"})

# EDIT MARKS
@app.route("/marks", methods=["PUT"])
def edit_marks():
    data = request.get_json()
    db = get_db()
    cursor = db.cursor()

    cursor.execute("""
        UPDATE marks
        SET marks=%s
        WHERE roll_no=%s AND subject_id=%s
    """, (
        data["marks"],
        data["roll_no"],
        data["subject_id"]
    ))

    db.commit()
    cursor.close()
    db.close()
    return jsonify({"message": "Marks updated successfully"})

# ================= RESULT =================

@app.route("/result/<roll_no>")
def get_result(roll_no):
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("""
        SELECT s.roll_no, s.name, s.semester, s.academic_year,
               sub.subject_name, m.marks
        FROM students s
        JOIN marks m ON s.roll_no = m.roll_no
        JOIN subjects sub ON m.subject_id = sub.id
        WHERE s.roll_no=%s
    """, (roll_no,))
    rows = cursor.fetchall()
    cursor.close()
    db.close()

    total = sum(r["marks"] for r in rows)
    percentage = (total / (len(rows) * 100)) * 100

    return jsonify({
        "roll_no": rows[0]["roll_no"],
        "name": rows[0]["name"],
        "semester": rows[0]["semester"],
        "academic_year": rows[0]["academic_year"],
        "subjects": rows,
        "total": total,
        "percentage": round(percentage, 2)
    })

# ================= RESULT PDF =================

@app.route("/result_pdf/<roll_no>")
def result_pdf(roll_no):
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("""
        SELECT s.roll_no, s.name, s.semester, s.academic_year,
               sub.subject_name, m.marks
        FROM students s
        JOIN marks m ON s.roll_no = m.roll_no
        JOIN subjects sub ON m.subject_id = sub.id
        WHERE s.roll_no=%s
    """, (roll_no,))
    rows = cursor.fetchall()
    cursor.close()
    db.close()

    buffer = io.BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=A4)

    pdf.setFont("Helvetica-Bold", 16)
    pdf.drawCentredString(300, 810, "STUDENT RESULT REPORT")

    pdf.setFont("Helvetica", 12)
    pdf.drawString(50, 770, f"Name: {rows[0]['name']}")
    pdf.drawString(50, 750, f"Roll No: {rows[0]['roll_no']}")
    pdf.drawString(50, 730, f"Semester: {rows[0]['semester']}")
    pdf.drawString(50, 710, f"Academic Year: {rows[0]['academic_year']}")

    pdf.setFont("Helvetica-Bold", 11)
    pdf.drawString(50, 680, "Subject")
    pdf.drawString(250, 680, "Marks")
    pdf.drawString(350, 680, "Grade")

    y = 660
    total = 0
    pdf.setFont("Helvetica", 11)

    for r in rows:
        grade = calculate_grade(r["marks"])
        pdf.drawString(50, y, r["subject_name"])
        pdf.drawString(250, y, str(r["marks"]))
        pdf.drawString(350, y, grade)
        total += r["marks"]
        y -= 20

    percentage = (total / (len(rows) * 100)) * 100
    pdf.setFont("Helvetica-Bold", 12)
    pdf.drawString(50, y - 20, f"Total Marks: {total}")
    pdf.drawString(50, y - 40, f"Percentage: {percentage:.2f}%")

    pdf.showPage()
    pdf.save()
    buffer.seek(0)

    return send_file(
        buffer,
        as_attachment=True,
        download_name=f"{roll_no}_result.pdf",
        mimetype="application/pdf"
    )

# ---------- RUN ----------
if __name__ == "__main__":
    app.run(debug=True)
